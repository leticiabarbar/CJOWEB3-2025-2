package br.edu.ifspcjo.ads.web3.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import br.edu.ifspcjo.ads.web3.domain.model.Category;
import br.edu.ifspcjo.ads.web3.repository.CategoryRepository;

@Service
public class CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	public Category update(Long id, Category category) {
		Category categorySaved = findCategoryById(id);
		BeanUtils.copyProperties(category, categorySaved, "id");

		return categoryRepository.save(categorySaved);
	}

	public Category findCategoryById(Long id) {
		Category categorySaved = categoryRepository.findById(id)
				.orElseThrow(() -> new EmptyResultDataAccessException(1));
		return categorySaved;
	}

	public void deleteCategoryById(Long id) {
		Category categorySaved = findCategoryById(id);
		categoryRepository.delete(categorySaved);
	}
}
